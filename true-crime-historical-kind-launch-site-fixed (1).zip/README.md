# True Crime of the Historical Kind — Launch Site

This is the launch-ready static site for **truecrimeofthehistoricalkindpodcast.com**.

## Included now
- Established archival/editorial visual design
- Approved main brand copy
- People / Place / Era positioning
- Cases 01–11 with published episode titles and direct Spotify episode links
- Case 12: The Salem Witch Trials, marked **In Production** with no unpublished episode titles or structure disclosed
- Direct public Spotify show link, Apple Podcasts, Amazon Music, Patreon, Instagram, and YouTube
- Host/about section

## Intentionally left out for now
- Bookshelf
- Case galleries
- Sideshow/bonus-episode section
- Any other feature whose final presentation has not yet been settled

These can be added later without replacing the site's overall design.

## Publishing with a Squarespace-registered domain
The site itself is static HTML/CSS/JS. It can be hosted on GitHub Pages (or another static host), while the domain remains registered at Squarespace. The included `CNAME` file contains the custom domain.

Do not upload the ZIP itself as a web page. Upload the *contents* of this folder to the chosen static host, then point the Squarespace domain DNS to that host according to the host's current custom-domain instructions.
