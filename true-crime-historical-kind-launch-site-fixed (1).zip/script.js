document.getElementById('year').textContent=new Date().getFullYear();
const btn=document.querySelector('.menu-toggle'),nav=document.querySelector('#nav');
btn?.addEventListener('click',()=>{const open=nav.classList.toggle('open');btn.setAttribute('aria-expanded',open)});
